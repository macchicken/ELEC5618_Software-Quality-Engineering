package test;

public final class MockJunit {


  public static void assumeTrue(String message,boolean condition){
    if (!condition){throw new AssertionError(message);}
  }

  /*
   * throw exception when condition is not satisfied
   */
  public static Boolean assertTrue(String message, boolean condition)
  {
    if (!condition) {
      fail(message);
    }
    return condition;
  }
  
  public static void fail(String message)
  {
    if (message == null) {
      throw new AssertionError();
    }
    throw new AssertionError(message);
  }

  public static void assertEquals(String message, Object expected, Object actual)
  {
    if (equalsRegardingNull(expected, actual)) {
      return;
    }
    if (((expected instanceof String)) && ((actual instanceof String)))
    {
      String cleanMessage = message == null ? "" : message;
      throw new AssertionError(cleanMessage+" expected: "+(String)expected+ " actual : "+(String)actual);
    }
    failNotEquals(message, expected, actual);
  }

  private static boolean equalsRegardingNull(Object expected, Object actual)
  {
    if (expected == null) {
      return actual == null;
    }
    return isEquals(expected, actual);
  }

  private static boolean isEquals(Object expected, Object actual)
  {
    return expected.equals(actual);
  }

  private static void failNotEquals(String message, Object expected, Object actual)
  {
    fail(format(message, expected, actual));
  }
  
  private static String format(String message, Object expected, Object actual)
  {
    String formatted = "";
    if ((message != null) && (!message.equals(""))) {
      formatted = message + " ";
    }
    String expectedString = String.valueOf(expected);
    String actualString = String.valueOf(actual);
    if (expectedString.equals(actualString)) {
      return formatted + "expected: " + formatClassAndValue(expected, expectedString) + " but was: " + formatClassAndValue(actual, actualString);
    }
    return formatted + "expected:<" + expectedString + "> but was:<" + actualString + ">";
  }
  
  private static String formatClassAndValue(Object value, String valueString)
  {
    String className = value == null ? "null" : value.getClass().getName();
    return className + "<" + valueString + ">";
  }

}
