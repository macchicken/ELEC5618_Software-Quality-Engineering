package test.fsm10;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Group;
import javax.media.j3d.Link;
import javax.media.j3d.Node;
import javax.media.j3d.Shape3D;

import test.MockJunit;
import mock.MockTestResouceFile;
import mock.ModelManager;
import mock.URLContent;


/**
 * Test ModelManager class.
 * 
 * Test ModelManager to load furniture model from various type of model files
 * there are 4 types of loader currently available in the system[OBJLoader,DAELoader,Max3DSLoader,Lw3dLoader]
 * Ensure model completely read in with no error
 * @author Hui Chen
 * test data:
 * coffee_machine.obj - expected 2 nodes
 * test.obj - expected  1 nodes
 * test.dae - expected  2 nodes
 * 
 * there are 2 type of tests, one is to test the loader in sequential order, the other is to load multiple files in concurrent thread
 */
public class MyModelManagerTest {
  private final CountDownLatch latch=new CountDownLatch(1);
  private ModelManager mma;
  private String resourceFile;
  private List<MockTestResouceFile> files;


  public void setUp(){
    this.mma=ModelManager.getInstance();
    this.resourceFile="resources/test.obj";
    this.files=new ArrayList<MockTestResouceFile>();
    this.files.add(new MockTestResouceFile("resources/test.obj",1));
    this.files.add(new MockTestResouceFile("resources/test.dae",2));
    this.files.add(new MockTestResouceFile("resources/coffee_machine.obj",2));
  }
  
  private int getShapesCount(Node node) {
    if (node instanceof Group) {
      int shapesCount = 0;
      Enumeration<?> enumeration = ((Group)node).getAllChildren();
      while (enumeration.hasMoreElements()) {
        shapesCount += getShapesCount((Node)enumeration.nextElement());
      }
      return shapesCount;
    } else if (node instanceof Link) {
      return getShapesCount(((Link)node).getSharedGroup());
    } else if (node instanceof Shape3D) {
      return 1;
    } else {
      return 0;
    }
  }

  /*
   * @param fileName - resource file name
   */
  public URLContent getResouce(String fileName){
    return new URLContent(MyModelManagerTest.class.getResource(fileName));
  }
  
  /*
   * @param fileName - resource file name
   * @param numOfNodes - expected number of nodes read in
   */
  public void testLoader(String fileName,int numOfNodes) throws IOException {
    BranchGroup model = mma.loadModel(getResouce(fileName));
    int count=getShapesCount(model);
    MockJunit.assumeTrue("Model is not empty", count > 0);
    try {
      System.out.println(MockJunit.assertTrue("Model should has "+numOfNodes+" number of nodes", count == numOfNodes));
    } catch (AssertionError ex) {
      System.out.println(ex.getMessage()+" actual is "+count);
    }
  }

  public void multiThreadTest(){
    for (final MockTestResouceFile file:files){
      new Thread() {
        @Override
        public void run() {
          try {
            latch.await();
          } catch (InterruptedException e) {
            e.printStackTrace();
          }
          try {
            testLoader(file.getFilePath(),((Integer)file.getExpected()).intValue());
          } catch (IOException ex) {
            ex.printStackTrace();
          }
        }
      }.start();
    }
    latch.countDown();
  }

  public void testSquentialLoading(){
    for (MockTestResouceFile file:files){
      try {
        testLoader(file.getFilePath(),((Integer)file.getExpected()).intValue());
      } catch (IOException ex) {
        ex.printStackTrace();
      }
    }
  }

  public String getResourceFile() {
    return this.resourceFile;
  }


  public static void main(String args[]) throws IOException{
    MyModelManagerTest tester=new MyModelManagerTest();
    tester.setUp();
//    tester.testLoader(tester.getResourceFile(),1);
      tester.testSquentialLoading();
//    tester.multiThreadTest();
  }


}
