package test.Markovchain11;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * holding a state transition list
 *
 */
public class State {

	private String start;
	private Map<Transition,Double> tlist=new HashMap<Transition,Double>();
	private double count=0;
	private Map<Transition,Double> probs=new HashMap<Transition,Double>();
	
	public State(String start,Transition trans,double count) {
		super();
		this.start = start;
		this.tlist.put(trans, count);
		this.count=count;
	}

	public String getStart() {
		return start;
	}

	public double getCount() {
		return count;
	}
	
	public void addTransition(Transition trans,double count){
		Double transCount=tlist.get(trans);
		if (transCount==null){
			transCount=count;
		}else{
			transCount=transCount+count;
		}
		tlist.put(trans, transCount);
		this.count=this.count+count;
	}
	
	public void computMKProbability(){
		Iterator<Entry<Transition, Double>> it=tlist.entrySet().iterator();
		while(it.hasNext()){
			Entry<Transition, Double> en=it.next();
			probs.put(en.getKey(), en.getValue()/count);
		}
	}

	public Map<Transition, Double> getProbs() {
		return probs;
	}

	@Override
	public String toString() {
		return "State [start=" + start + ", count=" + count + "]";
	}
	

}
