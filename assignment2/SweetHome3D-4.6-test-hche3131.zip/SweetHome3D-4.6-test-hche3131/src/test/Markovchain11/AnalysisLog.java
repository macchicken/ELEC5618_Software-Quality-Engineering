package test.Markovchain11;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Transition object would hold start state and end state of each state transition
 * State object would hold all possible transition of the 'start' state
 * @author Barry
 *
 */
public class AnalysisLog {

	private String fileName;
	private String workDir;
	private List<Transition> result;
	private Map<String,State> anresult;
	
	public AnalysisLog(String fileName) {
		this.fileName=fileName;
		this.workDir=System.getProperty("user.dir");
		this.result=new ArrayList<Transition>();
		this.anresult=new HashMap<String,State>();
	}
	
	/**
	 * read the log file from the file system and save the state transitions into intermediate storage "result"
	 */
	public void readLog(){
		Scanner scan =null;
		try {
			scan = new Scanner(new File(workDir+"\\src\\test\\Markovchain11\\"+fileName));
			String first=scan.nextLine(),second=null;
			while(scan.hasNext()){
				try {
					second=scan.nextLine();
				} catch (NoSuchElementException e) {
					break;
				}
				if (first.startsWith("loader")&&second.startsWith("loader")) {
					result.add(new Transition(first,second));
				}
				first=second;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally{
			if(scan!=null){scan.close();}
		}
	}

	/**
	 * traverse each state transition in the "result"
	 * count the 'total' number of each state transition in the list
	 * the probability of transition between 'from' and 'to' would be equal to
	 * divided that number of transitions by 'total' occurrence of those transitions start from
	 * the 'from' state
	 */
	public void analysis(){
		Iterator<Transition> it=result.iterator();
		while(it.hasNext()){
			Transition ts=it.next();
			String snode=ts.getFrom();
			State s=anresult.get(snode);
			if (s==null){
				s=new State(snode,ts,1.0);
				anresult.put(snode, s);
			}else{
				s.addTransition(ts, 1.0);
			}
		}
		Iterator<Entry<String, State>> sit=anresult.entrySet().iterator();
		while(sit.hasNext()){
			Entry<String, State> en=sit.next();
			en.getValue().computMKProbability();
		}
	}

	public void displayResult(){
		Iterator<Entry<String, State>> it=anresult.entrySet().iterator();
		while(it.hasNext()){
			State s=it.next().getValue();
			Map<Transition, Double> t=s.getProbs();
			Iterator<Entry<Transition, Double>> tit=t.entrySet().iterator();
			System.out.println("total transition start from "+s.getStart()+" is : "+s.getCount());
			while(tit.hasNext()){
				Entry<Transition, Double> ent=tit.next();
				System.out.print(ent.getKey());
				System.out.println(" probability: "+ent.getValue());
			}
		}
	}

	public static void main(String[] args) {
		AnalysisLog al=new AnalysisLog("loadModel_log.txt");
		al.readLog();
		al.analysis();
		al.displayResult();
	}

}
