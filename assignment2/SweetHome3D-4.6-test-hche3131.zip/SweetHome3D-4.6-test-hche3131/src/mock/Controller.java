package mock;


public interface Controller {

	public abstract View getView();
}
