package mock;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Group;
import javax.media.j3d.Light;
import javax.media.j3d.Link;
import javax.media.j3d.Material;
import javax.media.j3d.Node;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Texture;
import javax.media.j3d.TextureAttributes;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Color3f;

import com.sun.j3d.loaders.IncorrectFormatException;
import com.sun.j3d.loaders.Loader;
import com.sun.j3d.loaders.ParsingErrorException;
import com.sun.j3d.loaders.Scene;
import com.sun.j3d.loaders.lw3d.Lw3dLoader;


public class ModelManager {

	private static ModelManager instance;

	private ExecutorService modelsLoader;
	
	private Class<Loader> []          additionalLoaderClasses;
	public static final String WINDOW_PANE_SHAPE_PREFIX = "sweethome3d_window_pane";
	private static final TransparencyAttributes WINDOW_PANE_TRANSPARENCY_ATTRIBUTES = new TransparencyAttributes(TransparencyAttributes.NICEST, 0.5f);
	private static final Material               DEFAULT_MATERIAL = new Material();
	private static final String ADDITIONAL_LOADER_CLASSES = "com.eteks.sweethome3d.j3d.additionalLoaderClasses";

	private ModelManager() {
		List<Class<Loader>> loaderClasses = new ArrayList<Class<Loader>>();
		String loaderClassNames = System.getProperty(ADDITIONAL_LOADER_CLASSES);
	    if (loaderClassNames != null) {
	      for (String loaderClassName : loaderClassNames.split("\\s|:")) {
	        try {
	          loaderClasses.add(getLoaderClass(loaderClassName));
	        } catch (IllegalArgumentException ex) {
	          System.err.println("Invalid loader class " + loaderClassName + ":\n" + ex.getMessage());
	        }
	      }
	    }
	    this.additionalLoaderClasses = loaderClasses.toArray(new Class [loaderClasses.size()]);
	}

	/**
	   * Returns an instance of this singleton. 
	   */
	  public static ModelManager getInstance() {
	    if (instance == null) {
	      instance = new ModelManager();
	    }
	    return instance;
	  }

	  /**
	   * Returns the class of name <code>loaderClassName</code>.
	   */
	  @SuppressWarnings("unchecked")
	  private Class<Loader> getLoaderClass(String loaderClassName) {
	    try {
	      Class<Loader> loaderClass = (Class<Loader>)getClass().getClassLoader().loadClass(loaderClassName);
	      if (!Loader.class.isAssignableFrom(loaderClass)) {
	        throw new IllegalArgumentException(loaderClassName + " not a subclass of " + Loader.class.getName());
	      } else if (Modifier.isAbstract(loaderClass.getModifiers()) || !Modifier.isPublic(loaderClass.getModifiers())) {
	        throw new IllegalArgumentException(loaderClassName + " not a public static class");
	      }
	      Constructor<Loader> constructor = loaderClass.getConstructor(new Class [0]);
	      // Try to instantiate it now to see if it won't cause any problem
	      constructor.newInstance(new Object [0]);
	      return loaderClass;
	    } catch (ClassNotFoundException ex) {
	      throw new IllegalArgumentException(ex.getMessage(), ex);
	    } catch (NoSuchMethodException ex) {
	      throw new IllegalArgumentException(ex.getMessage(), ex);
	    } catch (InvocationTargetException ex) {
	      throw new IllegalArgumentException(ex.getMessage(), ex);
	    } catch (IllegalAccessException ex) {
	      throw new IllegalArgumentException(loaderClassName + " constructor not accessible");
	    } catch (InstantiationException ex) {
	      throw new IllegalArgumentException(loaderClassName + " not a public static class");
	    }
	  }

	  /**
	   * Returns the node loaded synchronously from <code>content</code> with supported loaders. 
	   * This method is threadsafe and may be called from any thread.
	   * @param content an object containing a model
	   */
	  public BranchGroup loadModel(Content content) throws IOException {
	    // Ensure we use a URLContent object
	    URLContent urlContent;
	    if (content instanceof URLContent) {
	      urlContent = (URLContent)content;
	    } else {
	      urlContent = TemporaryURLContent.copyToTemporaryURLContent(content);
	    }
	    Loader []  defaultLoaders = new Loader [] {new OBJLoader(),
	                                               new DAELoader(),
	                                               new Max3DSLoader(),
	                                               new Lw3dLoader()};
	    Loader [] loaders = new Loader [defaultLoaders.length + this.additionalLoaderClasses.length];
	    System.arraycopy(defaultLoaders, 0, loaders, 0, defaultLoaders.length);
	    for (int i = 0; i < this.additionalLoaderClasses.length; i++) {
	      try {
	        loaders [defaultLoaders.length + i] = this.additionalLoaderClasses [i].newInstance();
	      } catch (InstantiationException ex) {
	        // Can't happen: getLoaderClass checked this class is instantiable
	        throw new InternalError(ex.getMessage());
	      } catch (IllegalAccessException ex) {
	        // Can't happen: getLoaderClass checked this class is instantiable 
	        throw new InternalError(ex.getMessage());
	      } 
	    }
	    
	    Exception lastException = null;
	    Boolean useCaches = true;
	    for (Loader loader : loaders) {
	    	System.out.println("loader get");
	      boolean loadSynchronously = false;
	      try {
	        // Call setUseCaches(Boolean) by reflection
	        loader.getClass().getMethod("setUseCaches", Boolean.class).invoke(loader, useCaches);
	      } catch (NoSuchMethodException ex) {
	        // If the method setUseCaches doesn't exist, set default cache use if different 
	        // from the required one and load models synchronously
	        URLConnection connection = urlContent.getURL().openConnection();
	        loadSynchronously = connection.getDefaultUseCaches() != useCaches;        
	      } catch (InvocationTargetException ex) {
	        if (ex instanceof Exception) {
	          lastException = (Exception)ex.getTargetException();
	          continue;
	        } else {
	          ex.printStackTrace();
	        }
	      } catch (Exception ex) {
	        ex.printStackTrace();
	      }
	      
	      try {     
	        // Ask loader to ignore lights, fogs...
	        loader.setFlags(loader.getFlags() 
	            & ~(Loader.LOAD_LIGHT_NODES | Loader.LOAD_FOG_NODES 
	                | Loader.LOAD_BACKGROUND_NODES | Loader.LOAD_VIEW_GROUPS));
	        // Return the first scene that can be loaded from model URL content
	        Scene scene;
	        if (loadSynchronously) {
	          synchronized (this.modelsLoader) {
	            URLConnection connection = urlContent.getURL().openConnection();
	            try {
	              connection.setDefaultUseCaches(useCaches);
	              scene = loader.load(urlContent.getURL());
	            } finally {
	              if (connection.getDefaultUseCaches() == useCaches) {
	                // Restore the default global value only when it didn't change yet,
	                // in case an other thread not synchronized on the same lock changed it
	                connection.setDefaultUseCaches(!useCaches);
	              }
	            }
	          }
	        } else {
	          scene = loader.load(urlContent.getURL());
	        }
	        BranchGroup modelNode = scene.getSceneGroup();
	        // If model doesn't have any child, consider the file as wrong
	        if (modelNode.numChildren() == 0) {
	          throw new IllegalArgumentException("Empty model");
	        }
	        System.out.println("loader load");
	        // Update transparency of scene window panes shapes
	        updateShapeNamesAndWindowPanesTransparency(scene);        
	        // Turn off lights because some loaders don't take into account the ~LOAD_LIGHT_NODES flag
	        turnOffLightsShareAndModulateTextures(modelNode, new IdentityHashMap<Texture, Texture>());        
	        checkAppearancesName(modelNode);
	        System.out.println("loader finish");
	        return modelNode;
	      } catch (IllegalArgumentException ex) {
	        lastException = ex;
	        System.out.println("loader error format");
	      } catch (IncorrectFormatException ex) {
	        lastException = ex;
	        System.out.println("loader error format");
	      } catch (ParsingErrorException ex) {
	        lastException = ex;
	        System.out.println("loader error format");
	      } catch (IOException ex) {
	        lastException = ex;
	        System.out.println("loader error format");
	      } catch (RuntimeException ex) {
	        // Take into account exceptions of Java 3D 1.5 ImageException class
	        // in such a way program can run in Java 3D 1.3.1
	        if (ex.getClass().getName().equals("com.sun.j3d.utils.image.ImageException")) {
	          lastException = ex;
	        } else {
	          throw ex;
	        }
	      }
	    }
	    
	    if (lastException instanceof IOException) {
	      throw (IOException)lastException;
	    } else if (lastException instanceof IncorrectFormatException) {
	      IOException incorrectFormatException = new IOException("Incorrect format");
	      System.out.println("Incorrect format");
	      incorrectFormatException.initCause(lastException);
	      throw incorrectFormatException;
	    } else if (lastException instanceof ParsingErrorException) {
	      IOException incorrectFormatException = new IOException("Parsing error");
	      System.out.println("Parsing error");
	      incorrectFormatException.initCause(lastException);
	      throw incorrectFormatException;
	    } else {
	      IOException otherException = new IOException();
	      otherException.initCause(lastException);
	      System.out.println(otherException.getLocalizedMessage());
	      throw otherException;
	    } 
	  }

	  /**
	   * Updates the name of scene shapes and transparency window panes shapes.
	   */
	  @SuppressWarnings("unchecked")
	  private void updateShapeNamesAndWindowPanesTransparency(Scene scene) {
	    Map<String, Object> namedObjects = scene.getNamedObjects();
	    for (Map.Entry<String, Object> entry : namedObjects.entrySet()) {
	      if (entry.getValue() instanceof Shape3D) {
	        String shapeName = entry.getKey();
	        // Assign shape name to its user data
	        Shape3D shape = (Shape3D)entry.getValue();
	        shape.setUserData(shapeName);
	        if (shapeName.startsWith(WINDOW_PANE_SHAPE_PREFIX)) {
	          Appearance appearance = shape.getAppearance();
	          if (appearance == null) {
	            appearance = new Appearance();
	            shape.setAppearance(appearance);
	          }
	          if (appearance.getTransparencyAttributes() == null) {
	            appearance.setTransparencyAttributes(WINDOW_PANE_TRANSPARENCY_ATTRIBUTES);
	          }
	        }
	      }
	    }
	  }

	  /**
	   * Turns off light nodes of <code>node</code> children, 
	   * and modulates textures if needed.
	   */
	  private void turnOffLightsShareAndModulateTextures(Node node, 
	                                                     Map<Texture, Texture> replacedTextures) {
	    if (node instanceof Group) {
	      // Enumerate children
	      Enumeration<?> enumeration = ((Group)node).getAllChildren(); 
	      while (enumeration.hasMoreElements()) {
	        turnOffLightsShareAndModulateTextures((Node)enumeration.nextElement(), replacedTextures);
	      }
	    } else if (node instanceof Link) {
	      turnOffLightsShareAndModulateTextures(((Link)node).getSharedGroup(), replacedTextures);
	    } else if (node instanceof Light) {
	      ((Light)node).setEnable(false);
	    } else if (node instanceof Shape3D) {
	      Appearance appearance = ((Shape3D)node).getAppearance();
	      if (appearance != null) {
	        Texture texture = appearance.getTexture();
	        if (texture != null) {
	          // Share textures data as much as possible requesting TextureManager#shareTexture the less often possible
	          Texture sharedTexture = replacedTextures.get(texture);
	          if (sharedTexture == null) {
	            sharedTexture = TextureManager.getInstance().shareTexture(texture);
	            replacedTextures.put(texture, sharedTexture);
	          }
	          if (sharedTexture != texture) {
	            appearance.setTexture(sharedTexture);
	          }
	          TextureAttributes textureAttributes = appearance.getTextureAttributes();
	          if (textureAttributes == null) {
	            // Mix texture and shape color
	            textureAttributes = new TextureAttributes();
	            textureAttributes.setTextureMode(TextureAttributes.MODULATE);
	            appearance.setTextureAttributes(textureAttributes);
	            // Check shape color is white
	            Material material = appearance.getMaterial();
	            if (material == null) {
	              appearance.setMaterial((Material)DEFAULT_MATERIAL.cloneNodeComponent(true));
	            } else {
	              Color3f color = new Color3f();
	              DEFAULT_MATERIAL.getDiffuseColor(color);
	              material.setDiffuseColor(color);
	              DEFAULT_MATERIAL.getAmbientColor(color);
	              material.setAmbientColor(color);
	            }
	          }
	          
	          // If texture image supports transparency
	          if (TextureManager.getInstance().isTextureTransparent(sharedTexture)) {
	            if (appearance.getTransparencyAttributes() == null) {
	              // Add transparency attributes to ensure transparency works
	              appearance.setTransparencyAttributes(
	                  new TransparencyAttributes(TransparencyAttributes.NICEST, 0));
	            }             
	          }
	        }
	      }
	    } 
	  }

	  /** 
	   * Ensures that all the appearance of the children shapes of the 
	   * given <code>node</code> have a name.
	   */
	  public void checkAppearancesName(Node node) {
	    // Search appearances used by node shapes keeping their enumeration order 
	    Set<Appearance> appearances = new LinkedHashSet<Appearance>(); 
	    searchMaterials(node, appearances);
	    int i = 0;
	    for (Appearance appearance : appearances) {
	      try {
	        if (appearance.getName() == null) {
	          appearance.setName("Texture_" + ++i);
	        }
	      } catch (NoSuchMethodError ex) {
	        // Don't support HomeMaterial with Java 3D < 1.4 where appearance name was added
	        break;
	      }
	    }
	  }

	  private void searchMaterials(Node node, Set<Appearance> appearances) {
		    if (node instanceof Group) {
		      // Enumerate children
		      Enumeration<?> enumeration = ((Group)node).getAllChildren(); 
		      while (enumeration.hasMoreElements()) {
		        searchMaterials((Node)enumeration.nextElement(), appearances);
		      }
		    } else if (node instanceof Link) {
		      searchMaterials(((Link)node).getSharedGroup(), appearances);
		    } else if (node instanceof Shape3D) {
		      Appearance appearance = ((Shape3D)node).getAppearance();
		      if (appearance != null) {
		        appearances.add(appearance);
		      }
		    }
		  }

}
