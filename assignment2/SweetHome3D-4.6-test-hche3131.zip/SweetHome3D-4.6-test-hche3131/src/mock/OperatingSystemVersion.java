package mock;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;




// extract the compareVersions method from com.eteks.sweethome3d.tools.OperatingSystem
public class OperatingSystemVersion {

  public OperatingSystemVersion() {}


  /**
   * Returns negative values if the given version part matches a pre release (i.e. alpha, beta, rc)
   * or returns the parameter itself.
   */
  private Object convertPreReleaseVersion(Object versionPart) {
    if (versionPart instanceof String) {
      String versionPartString = (String)versionPart;
      if ("alpha".equalsIgnoreCase(versionPartString)) {
        return new BigInteger("-3");
      } else if ("beta".equalsIgnoreCase(versionPartString)) {
        return new BigInteger("-2");
      } else if ("rc".equalsIgnoreCase(versionPartString)) {
        return new BigInteger("-1");
      }
    }
    return versionPart;
  }

  /**
   * Returns the substrings components of the given <code>version</code>.
   */
  private List<Object> splitVersion(String version) {
    List<Object> versionParts = new ArrayList<Object>();
    StringBuilder subPart = new StringBuilder();
    // First split version with punctuation (One of !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~) and space
    for (String part : version.split("\\p{Punct}|\\s")) {// # for 1
      for (int i = 0; i < part.length(); ) {// # for 2
        subPart.setLength(0);
        char c = part.charAt(i);
        if (Character.isDigit(c)) {
          for ( ; i < part.length() && Character.isDigit(c = part.charAt(i)); i++) {// # for 3
            subPart.append(c);
          }
          versionParts.add(new BigInteger(subPart.toString()));
        } else {
          for ( ; i < part.length() && !Character.isDigit(c = part.charAt(i)); i++) {// # for 4
            subPart.append(c);
          }
          versionParts.add(subPart.toString());
        }
      }
    }
    return versionParts;
  }

  /**
   * Returns a negative number if version1 smaller than version2,
   * 0 if version1 equal to version2
   * and a positive number if version1 greater than version2.
   */
  public int compareVersions(String version1, String version2) {
    List<Object> version1Parts = splitVersion(version1);
    List<Object> version2Parts = splitVersion(version2);
    int i = 0;
    for ( ; i < version1Parts.size() || i < version2Parts.size(); i++) {// compareVersions # for 1
      Object version1Part = i < version1Parts.size() 
          ? convertPreReleaseVersion(version1Parts.get(i))
          : BigInteger.ZERO; // Missing part is considered as 0
      Object version2Part = i < version2Parts.size() 
          ? convertPreReleaseVersion(version2Parts.get(i))
          : BigInteger.ZERO;
      if (version1Part.getClass() == version2Part.getClass()) {
        @SuppressWarnings({"unchecked", "rawtypes"})
        int comparison = ((Comparable)version1Part).compareTo(version2Part);
        if (comparison != 0) {
          return comparison;
        }
      } else if (version1Part instanceof String) {
        // An integer subpart is smaller than a string (except for pre release strings)
        return 1;
      } else {
        // A string subpart is greater than an integer 
        return -1;
      }
    }
    return 0;
  }

  /**
   * Returns <code>true</code> if current operating is Windows.
   */
  public static boolean isWindows() {
    return System.getProperty("os.name").startsWith("Windows");
  }

  /**
   * Returns a temporary file that will be deleted when JVM will exit.
   * @throws IOException if the file couldn't be created
   */
  public static File createTemporaryFile(String prefix, String suffix) throws IOException {
    File temporaryFolder=new File("tempfile");
    File temporaryFile = File.createTempFile(prefix, suffix, temporaryFolder);
    temporaryFile.deleteOnExit();
    return temporaryFile;
  }

  
}
