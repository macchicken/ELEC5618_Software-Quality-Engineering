package mock;

public class MockTestResouceFile {

  private String filePath;
  private Object expected;

  public MockTestResouceFile(String filePath, Object expected) {
    this.filePath=filePath;
    this.expected=expected;
  }

  public Object getExpected() {
    return this.expected;
  }

  public String getFilePath() {
    return this.filePath;
  }

}
