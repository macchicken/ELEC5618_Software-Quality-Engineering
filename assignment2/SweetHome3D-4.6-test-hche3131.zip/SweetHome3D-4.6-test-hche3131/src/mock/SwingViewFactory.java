package mock;


public class SwingViewFactory implements ViewFactory {

	public SwingViewFactory() {
	}

	@Override
	public ThreadedTaskView createThreadedTaskView(String taskMessage,
			UserPreferences preferences,
			ThreadedTaskController threadedTaskController) {
		return new ThreadedTaskPanel(taskMessage, preferences, threadedTaskController);
	}

}
