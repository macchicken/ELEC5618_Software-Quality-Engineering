package mock;

public interface View {

}
