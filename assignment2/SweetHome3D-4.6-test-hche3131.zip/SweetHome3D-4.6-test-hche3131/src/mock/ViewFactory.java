package mock;


public interface ViewFactory {

	/**
	   * Returns a new view that displays message for a threaded task.
	   */
	  public abstract ThreadedTaskView createThreadedTaskView(String taskMessage,
	                                                          UserPreferences userPreferences, 
	                                                          ThreadedTaskController threadedTaskController);

}
