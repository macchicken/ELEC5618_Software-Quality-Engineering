package mock;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import javax.media.j3d.ImageComponent;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Texture;


public class TextureManager {

	private static TextureManager instance;

	private final Map<Texture, ComparableTexture>                 textures;
	private final Map<Content, List<ComparableTextureAngleTuple>> contentTextures;

	private TextureManager() {
		this.textures = new WeakHashMap<Texture, ComparableTexture>();
		this.contentTextures = new WeakHashMap<Content, List<ComparableTextureAngleTuple>>();
	}

	/**
	   * Returns an instance of this singleton. 
	   */
	  public static TextureManager getInstance() {
	    if (instance == null) {
	      instance = new TextureManager();
	    }
	    return instance;
	  }

	/**
	   * Returns either the <code>texture</code> in parameter or a shared texture 
	   * if the same texture as the one in parameter is already shared.
	   */
	  public Texture shareTexture(Texture texture) {
	    return shareTexture(texture, 0, null);
	  }
	  
	  /**
	   * Returns the texture matching <code>content</code>, either 
	   * the <code>texture</code> in parameter or a shared texture if the 
	   * same texture as the one in parameter is already shared.
	   */
	  private Texture shareTexture(final Texture texture,
	                               final float   angle,
	                               final Content content) {
	    ComparableTexture textureData = new ComparableTexture(texture);
	    Texture sharedTexture = null;
	    synchronized (this.textures) { // Use one mutex for both maps
	      // Search which existing key matches texture key to share unique texture
	      for (Map.Entry<Texture, ComparableTexture> entry : this.textures.entrySet()) {
	        if (textureData.equalsImage(entry.getValue())) {
	          sharedTexture = entry.getKey();
	          textureData = entry.getValue(); 
	          break;
	        }
	      }
	      if (sharedTexture == null) {
	        sharedTexture = texture;
	        setSharedTextureAttributesAndCapabilities(sharedTexture);
	        this.textures.put(sharedTexture, textureData);
	      }
	      if (content != null) {
	        List<ComparableTextureAngleTuple> contentTexturesList = this.contentTextures.get(content);
	        if (contentTexturesList == null) {
	          contentTexturesList = new ArrayList<ComparableTextureAngleTuple>(1);
	          this.contentTextures.put(content, contentTexturesList);
	        }
	        contentTexturesList.add(new ComparableTextureAngleTuple(textureData, angle));
	      }
	    }
	    return sharedTexture;
	  }

	  /**
	   * Sets the attributes and capabilities of a shared <code>texture</code>.
	   */
	  private void setSharedTextureAttributesAndCapabilities(Texture texture) {
	    if (!texture.isLive()) {
	      texture.setMinFilter(Texture.NICEST);
	      texture.setMagFilter(Texture.NICEST);
	      texture.setCapability(Texture.ALLOW_FORMAT_READ);
	      texture.setCapability(Texture.ALLOW_IMAGE_READ);
	      for (ImageComponent image : texture.getImages()) {
	        if (!image.isLive()) {
	          image.setCapability(ImageComponent.ALLOW_FORMAT_READ);
	          image.setCapability(ImageComponent.ALLOW_IMAGE_READ);
	        }
	      }
	    }
	  }

	  /**
	   * Texture used to compare textures images and ensure texture uniqueness in textures map.
	   * Image bits of the texture are stored in a weak reference to avoid grabbing memory uselessly.
	   */
	  private static class ComparableTexture {
	    private Texture               texture;
	    private WeakReference<int []> imageBits;
	    private Integer               imageBitsHashCode;
	    private Boolean               transparent;

	    public ComparableTexture(Texture texture) {
	      this.texture = texture;      
	    }
	    
	    public Texture getTexture() {
	      return this.texture;
	    }
	    
	    /**
	     * Returns the pixels of the given <code>image</code>.
	     */
	    private int [] getImageBits() {
	      int [] imageBits = null;
	      if (this.imageBits != null) {
	        imageBits = this.imageBits.get();
	      }
	      if (imageBits == null) {
	        BufferedImage image = ((ImageComponent2D)this.texture.getImage(0)).getImage();
	        if (image.getType() != BufferedImage.TYPE_INT_RGB
	            && image.getType() != BufferedImage.TYPE_INT_ARGB) {
	          // Transform as TYPE_INT_ARGB or TYPE_INT_RGB (much faster than calling image.getRGB())
	          BufferedImage tmp = new BufferedImage(image.getWidth(), image.getHeight(), 
	              this.texture.getFormat() == Texture.RGBA ? BufferedImage.TYPE_INT_ARGB : BufferedImage.TYPE_INT_RGB);
	          Graphics2D g = (Graphics2D)tmp.getGraphics();
	          g.drawImage(image, null, 0, 0);
	          g.dispose();
	          image = tmp;
	        }
	        imageBits = (int [])image.getRaster().getDataElements(0, 0, image.getWidth(), image.getHeight(), null);
	        this.transparent = image.getTransparency() != BufferedImage.OPAQUE;
	        if (this.transparent) {
	          this.transparent = containsTransparentPixels(imageBits);
	        }
	        this.imageBits = new WeakReference<int[]>(imageBits);
	      }
	      return imageBits;
	    }

	    /**
	     * Returns an hash code for the image of the texture that allows
	     * a faster comparison and storing images bits in a weak reference.
	     */
	    private int getImageBitsHashCode() {
	      if (this.imageBitsHashCode == null) {
	        this.imageBitsHashCode = Arrays.hashCode(getImageBits());
	      }
	      return this.imageBitsHashCode;
	    }
	    
	    /**
	     * Returns <code>true</code> if the image contains at least a transparent pixel. 
	     */
	    private boolean containsTransparentPixels(int [] imageBits) {
	      boolean transparentPixel = false;
	      for (int argb : imageBits) {
	        if ((argb & 0xFF000000) != 0xFF000000) {
	          transparentPixel = true;
	          break;
	        }
	      }
	      return transparentPixel;
	    }

	    /**
	     * Returns <code>true</code> if the image of the texture contains at least one transparent pixel.
	     */
	    public boolean isTransparent() {
	      if (this.transparent == null) {
	        getImageBits();
	      }
	      return this.transparent;
	    }
	    
	    /**
	     * Returns <code>true</code> if the image of this texture and 
	     * the image of the object in parameter are the same. 
	     */
	    public boolean equalsImage(ComparableTexture comparableTexture) {
	      if (this == comparableTexture) {
	        return true;
	      } else if (this.texture == comparableTexture.texture) {
	        return true;
	      } else if (getImageBitsHashCode() == comparableTexture.getImageBitsHashCode()){
	        return Arrays.equals(getImageBits(), comparableTexture.getImageBits());
	      }
	      return false;
	    }
	  }

	  /**
	   * Returns <code>true</code> if the texture is shared and its image contains 
	   * at least one transparent pixel.
	   */
	  public boolean isTextureTransparent(Texture texture) {
	    synchronized (this.textures) { // Use one mutex for both maps
	      ComparableTexture textureData = this.textures.get(texture);
	      if (textureData != null) {
	        return textureData.isTransparent();
	      }
	      return texture.getFormat() == Texture.RGBA;
	    }
	  }

	  /** 
	   * A tuple that associates a texture and one of its possible rotation angle.
	   */
	  private static class ComparableTextureAngleTuple {
	    private ComparableTexture texture;
	    private float             angle;

	    public ComparableTextureAngleTuple(ComparableTexture texture, float angle) {
	      this.texture = texture;
	      this.angle = angle;
	    }

	    public Texture getTexture() {
	      return this.texture.getTexture();
	    }
	    
	    public float getAngle() {
	      return this.angle;
	    }
	  }
}
