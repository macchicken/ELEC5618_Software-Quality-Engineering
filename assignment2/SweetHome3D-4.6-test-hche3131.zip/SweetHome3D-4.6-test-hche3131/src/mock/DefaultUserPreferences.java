/*
 * DefaultUserPreferences.java 15 mai 2006
 *
 * Sweet Home 3D, Copyright (c) 2006 Emmanuel PUYBARET / eTeks <info@eteks.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package mock;



/**
 * Default user preferences.
 * @author Barry
 */
public class DefaultUserPreferences extends UserPreferences {
  /**
   * Creates default user preferences read from resource files in the default language.
   */
  public DefaultUserPreferences() {
    this(true, null);
  }
  
  /**
   * Creates default user preferences read from resource files.
   * @param readCatalogs          if <code>false</code> furniture and texture catalog won't be read
   * @param localizedPreferences  preferences used to read localized resource files
   */
  DefaultUserPreferences(boolean readCatalogs,
                         UserPreferences localizedPreferences) {
    if (localizedPreferences == null) {
      localizedPreferences = this;
      setLanguage(localizedPreferences.getLanguage());
      setNewWallThickness(new Float(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "newWallThickness")));
      setNewWallHeight(Float.parseFloat(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "newHomeWallHeight")));
      setNewFloorThickness(Float.parseFloat(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "newFloorThickness")));
      setCheckUpdatesEnabled(Boolean.parseBoolean(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "checkUpdatesEnabled")));
      setCurrency(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "currency"));
    } else {
      setLanguage(localizedPreferences.getLanguage());
      setNewWallThickness(new Float(this.getLocalizedString(DefaultUserPreferences.class, "newWallThickness")));
      setNewWallHeight(Float.parseFloat(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "newHomeWallHeight")));
      setNewFloorThickness(Float.parseFloat(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "newFloorThickness")));
      setCheckUpdatesEnabled(Boolean.parseBoolean(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "checkUpdatesEnabled")));
      setCurrency(localizedPreferences.getLocalizedString(DefaultUserPreferences.class, "currency"));
    }
    
  }
  
}
